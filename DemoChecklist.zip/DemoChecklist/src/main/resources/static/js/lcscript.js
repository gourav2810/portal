var app = angular.module('myApp', []); 
app.controller('todoCtrl', function($scope, $http,$timeout) {
	
	var urlBase="";
	$scope.Submit = "Submit";
	$scope.submittedCount = 0;
	$scope.app = ['r1', 'r2', 'r3', 'r4', 'r5', 'r6', 'r7', 'r8', 'r9', 'r10', 'r12', 'r13', 'r14', 'r15', 'r16', 'r17', 'r18', 'r19', 'r20', 'r21', 'r22', 'r23', 'r24','r25'];
	
	
	
	//Gourav_enhancement
	
	$scope.totalattempt = 0;
    //Gourav_enhancement
	
	
    $scope.decide = function() {
		if($scope.submittedCount ==0){
			$scope.submittedCount = 1;
			$scope.makeData();
			
			var i =0,temp,temp1,sum=0;
			for(i=0;i<24;i++)
			{
				temp = document.querySelector('input[name="'+$scope.app[i]+'"]:checked').value;
				temp1 = parseInt(temp);
				if(temp1 != 0)
				{
					$scope.totalattempt++;
					sum = sum +temp1;
				}
			}
			
			console.log("AttemptedQuestions:"+$scope.totalattempt);
			console.log("TotalScore:"+sum);
				avg = sum/$scope.totalattempt;
				avg1 = Math.round(avg * 100) / 100;
				var x = document.getElementById("resDIV");
				x.style.display = "block";
				document.getElementById("result").innerHTML = "Your Score is <strong>" + avg1 + "</strong> out of <strong>5</strong>";
				document.getElementById("resultInModal").innerHTML = "Your Score is <strong>" + avg1 + "</strong> out of <strong>5</strong><br>"+"Please take a print(or save as PDF) of your response in the next screen to identify self-improvement actions.";
				angular.element('#myModalShower').trigger('click');
				//$timeout(function () { angular.element('#resultModalClose').trigger('click'); }, 2800); //to close the result modal
				//$scope.timeoutvar = $timeout(function () { window.print(); }, 3000);
				$scope.Submit = "Print";
				
			
	
		}
		else{
				window.print();
			}
    };
	
	
	
	
	
	$scope.makeData = function() {
		var platform1 = document.getElementById('platform').value;
		var loc = document.getElementById('location').value;
		var user1 =document.getElementById('user').value;
		var self_flag1 =document.getElementById('self_flag').value;
		if(self_flag1 =="M")
			{
			var manage = document.getElementById('manage').value;
			}
		else
			{
			var manage=null;
			}
		
		console.log(platform);
		console.log(loc);
		var date = new Date();
	    var n = date.toISOString();
	    var time =n.substring(0,10)+' '+date.toLocaleTimeString();
	    
		$http.post(urlBase + '/checklists', {
			username: user1 ,
            platform: platform1,
            location: loc,
            self_flag: self_flag1,
            manager_username: manage,
            question1: $scope.r1,
            question2: $scope.r2,
            question3: $scope.r3,
            question4: $scope.r4,
            question5: $scope.r5,
            question6: $scope.r6,
            question7: $scope.r7,
            question8: $scope.r8,
            question9: $scope.r9,
            question10: $scope.r10,
            question11: $scope.r12,
            question12: $scope.r13,
            question13: $scope.r14,
            question14: $scope.r15,
            question15: $scope.r16,
            question16: $scope.r17,
            question17: $scope.r18,
            question18: $scope.r19,
            question19: $scope.r20,
            question20: $scope.r21,
            question21: $scope.r22,
            question22: $scope.r23,
            question23: $scope.r24,
            question24: $scope.r25,
            status: 'active',
            survey_time: time
            
        }).
		  success(function(data, status, headers) {
			 alert("Survey added");
		    });
		}
		
	
		
		
});