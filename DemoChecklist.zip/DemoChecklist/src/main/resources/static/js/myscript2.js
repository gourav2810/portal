var app = angular.module('myApp1', []); 
app.controller('todoCtrl', function($scope, $http,$timeout) {
	$scope.selectOption = 'totalData';
	$scope.selectOption2 = 'totalData';
	$scope.selectOption3 = 'totalData';
	var urlBase="";
    $scope.platforms = ["Accounting Solutions","Credit Risk Solutions","EPM and Markets Solutions","Non-Financial Risk Solutions",
												"Reporting Solutions","Treasury Solutions","HR Solutions","ICB Transformation",
													"Resolutions Planning and Brexit","Technology Transformation","Treasury Transformation",
																		"Performance & Business Management"];
	
	$scope.locations = ["London","Edinburgh","Bangalore","Chennai","Gurugram"];
	
	$scope.cleanData = function() {
		$scope.rowTotalM = 0;
		$scope.rowTotalS = 0;
		$scope.r1NeverM = 0;$scope.r1SometimesM = 0;$scope.r1OftenM = 0;$scope.r1MostlyM = 0;$scope.r1AlwaysM = 0;$scope.r1NAM = 0;$scope.r1AvgM = 0;
		$scope.r2NeverM = 0;$scope.r2SometimesM = 0;$scope.r2OftenM = 0;$scope.r2MostlyM = 0;$scope.r2AlwaysM = 0;$scope.r2NAM = 0;$scope.r2AvgM = 0;
		$scope.r3NeverM = 0;$scope.r3SometimesM = 0;$scope.r3OftenM = 0;$scope.r3MostlyM = 0;$scope.r3AlwaysM = 0;$scope.r3NAM = 0;$scope.r3AvgM = 0;
		$scope.r4NeverM = 0;$scope.r4SometimesM = 0;$scope.r4OftenM = 0;$scope.r4MostlyM = 0;$scope.r4AlwaysM = 0;$scope.r4NAM = 0;$scope.r4AvgM = 0;
		$scope.r5NeverM = 0;$scope.r5SometimesM = 0;$scope.r5OftenM = 0;$scope.r5MostlyM = 0;$scope.r5AlwaysM = 0;$scope.r5NAM = 0;$scope.r5AvgM = 0;
		$scope.r6NeverM = 0;$scope.r6SometimesM = 0;$scope.r6OftenM = 0;$scope.r6MostlyM = 0;$scope.r6AlwaysM = 0;$scope.r6NAM = 0;$scope.r6AvgM = 0;
		$scope.r7NeverM = 0;$scope.r7SometimesM = 0;$scope.r7OftenM = 0;$scope.r7MostlyM = 0;$scope.r7AlwaysM = 0;$scope.r7NAM = 0;$scope.r7AvgM = 0;
		$scope.r8NeverM = 0;$scope.r8SometimesM = 0;$scope.r8OftenM = 0;$scope.r8MostlyM = 0;$scope.r8AlwaysM = 0;$scope.r8NAM = 0;$scope.r8AvgM = 0;
		$scope.r9NeverM = 0;$scope.r9SometimesM = 0;$scope.r9OftenM = 0;$scope.r9MostlyM = 0;$scope.r9AlwaysM = 0;$scope.r9NAM = 0;$scope.r9AvgM = 0;
		$scope.r10NeverM = 0;$scope.r10SometimesM = 0;$scope.r10OftenM = 0;$scope.r10MostlyM = 0;$scope.r10AlwaysM = 0;$scope.r10NAM = 0;$scope.r10AvgM = 0;
	//	$scope.r11Never = 0;$scope.r11Sometimes = 0;$scope.r11Often = 0;$scope.r11Mostly = 0;$scope.r11Always = 0;$scope.r11NA = 0;$scope.r11Avg = 0;
		$scope.r12NeverM = 0;$scope.r12SometimesM = 0;$scope.r12OftenM = 0;$scope.r12MostlyM = 0;$scope.r12AlwaysM = 0;$scope.r12NAM = 0;$scope.r12AvgM = 0;
		$scope.r13NeverM = 0;$scope.r13SometimesM = 0;$scope.r13OftenM = 0;$scope.r13MostlyM = 0;$scope.r13AlwaysM = 0;$scope.r13NAM = 0;$scope.r13AvgM = 0;
		$scope.r14NeverM = 0;$scope.r14SometimesM = 0;$scope.r14OftenM = 0;$scope.r14MostlyM = 0;$scope.r14AlwaysM = 0;$scope.r14NAM = 0;$scope.r14AvgM = 0;
		$scope.r15NeverM = 0;$scope.r15SometimesM = 0;$scope.r15OftenM = 0;$scope.r15MostlyM = 0;$scope.r15AlwaysM = 0;$scope.r15NAM = 0;$scope.r15AvgM = 0;
		$scope.r16NeverM = 0;$scope.r16SometimesM = 0;$scope.r16OftenM = 0;$scope.r16MostlyM = 0;$scope.r16AlwaysM = 0;$scope.r16NAM = 0;$scope.r16AvgM = 0;
		$scope.r17NeverM = 0;$scope.r17SometimesM = 0;$scope.r17OftenM = 0;$scope.r17MostlyM = 0;$scope.r17AlwaysM = 0;$scope.r17NAM = 0;$scope.r17AvgM = 0;
		$scope.r18NeverM = 0;$scope.r18SometimesM = 0;$scope.r18OftenM = 0;$scope.r18MostlyM = 0;$scope.r18AlwaysM = 0;$scope.r18NAM = 0;$scope.r18AvgM = 0;
		$scope.r19NeverM = 0;$scope.r19SometimesM = 0;$scope.r19OftenM = 0;$scope.r19MostlyM = 0;$scope.r19AlwaysM = 0;$scope.r19NAM = 0;$scope.r19AvgM = 0;
		$scope.r20NeverM = 0;$scope.r20SometimesM = 0;$scope.r20OftenM = 0;$scope.r20MostlyM = 0;$scope.r20AlwaysM = 0;$scope.r20NAM = 0;$scope.r20AvgM = 0;
		$scope.r21NeverM = 0;$scope.r21SometimesM = 0;$scope.r21OftenM = 0;$scope.r21MostlyM = 0;$scope.r21AlwaysM = 0;$scope.r21NAM = 0;$scope.r21AvgM = 0;
		$scope.r22NeverM = 0;$scope.r22SometimesM = 0;$scope.r22OftenM = 0;$scope.r22MostlyM = 0;$scope.r22AlwaysM = 0;$scope.r22NAM = 0;$scope.r22AvgM = 0;
		$scope.r23NeverM = 0;$scope.r23SometimesM = 0;$scope.r23OftenM = 0;$scope.r23MostlyM = 0;$scope.r23AlwaysM = 0;$scope.r23NAM = 0;$scope.r23AvgM = 0;
		$scope.r24NeverM = 0;$scope.r24SometimesM = 0;$scope.r24OftenM = 0;$scope.r24MostlyM = 0;$scope.r24AlwaysM = 0;$scope.r24NAM = 0;$scope.r24AvgM = 0;
		$scope.r25NeverM = 0;$scope.r25SometimesM = 0;$scope.r25OftenM = 0;$scope.r25MostlyM = 0;$scope.r25AlwaysM = 0;$scope.r25NAM = 0;$scope.r25AvgM = 0;
		$scope.r1NeverS = 0;$scope.r1SometimesS = 0;$scope.r1OftenS = 0;$scope.r1MostlyS = 0;$scope.r1AlwaysS = 0;$scope.r1NAS = 0;$scope.r1AvgS = 0;
		$scope.r2NeverS = 0;$scope.r2SometimesS = 0;$scope.r2OftenS = 0;$scope.r2MostlyS = 0;$scope.r2AlwaysS = 0;$scope.r2NAS = 0;$scope.r2AvgS = 0;
		$scope.r3NeverS = 0;$scope.r3SometimesS = 0;$scope.r3OftenS = 0;$scope.r3MostlyS = 0;$scope.r3AlwaysS = 0;$scope.r3NAS = 0;$scope.r3AvgS = 0;
		$scope.r4NeverS = 0;$scope.r4SometimesS = 0;$scope.r4OftenS = 0;$scope.r4MostlyS = 0;$scope.r4AlwaysS = 0;$scope.r4NAS = 0;$scope.r4AvgS = 0;
		$scope.r5NeverS = 0;$scope.r5SometimesS = 0;$scope.r5OftenS = 0;$scope.r5MostlyS = 0;$scope.r5AlwaysS = 0;$scope.r5NAS = 0;$scope.r5AvgS = 0;
		$scope.r6NeverS = 0;$scope.r6SometimesS = 0;$scope.r6OftenS = 0;$scope.r6MostlyS = 0;$scope.r6AlwaysS = 0;$scope.r6NAS = 0;$scope.r6AvgS = 0;
		$scope.r7NeverS = 0;$scope.r7SometimesS = 0;$scope.r7OftenS = 0;$scope.r7MostlyS = 0;$scope.r7AlwaysS = 0;$scope.r7NAS = 0;$scope.r7AvgS = 0;
		$scope.r8NeverS = 0;$scope.r8SometimesS = 0;$scope.r8OftenS = 0;$scope.r8MostlyS = 0;$scope.r8AlwaysS = 0;$scope.r8NAS = 0;$scope.r8AvgS = 0;
		$scope.r9NeverS = 0;$scope.r9SometimesS = 0;$scope.r9OftenS = 0;$scope.r9MostlyS = 0;$scope.r9AlwaysS = 0;$scope.r9NAS = 0;$scope.r9AvgS = 0;
		$scope.r10NeverS = 0;$scope.r10SometimesS = 0;$scope.r10OftenS = 0;$scope.r10MostlyS = 0;$scope.r10AlwaysS = 0;$scope.r10NAS = 0;$scope.r10AvgS = 0;
	//	$scope.r11Never = 0;$scope.r11Sometimes = 0;$scope.r11Often = 0;$scope.r11Mostly = 0;$scope.r11Always = 0;$scope.r11NA = 0;$scope.r11Avg = 0;
		$scope.r12NeverS = 0;$scope.r12SometimesS = 0;$scope.r12OftenS = 0;$scope.r12MostlyS = 0;$scope.r12AlwaysS = 0;$scope.r12NAS = 0;$scope.r12AvgS = 0;
		$scope.r13NeverS = 0;$scope.r13SometimesS = 0;$scope.r13OftenS = 0;$scope.r13MostlyS = 0;$scope.r13AlwaysS = 0;$scope.r13NAS = 0;$scope.r13AvgS = 0;
		$scope.r14NeverS = 0;$scope.r14SometimesS = 0;$scope.r14OftenS = 0;$scope.r14MostlyS = 0;$scope.r14AlwaysS = 0;$scope.r14NAS = 0;$scope.r14AvgS = 0;
		$scope.r15NeverS = 0;$scope.r15SometimesS = 0;$scope.r15OftenS = 0;$scope.r15MostlyS = 0;$scope.r15AlwaysS = 0;$scope.r15NAS = 0;$scope.r15AvgS = 0;
		$scope.r16NeverS = 0;$scope.r16SometimesS = 0;$scope.r16OftenS = 0;$scope.r16MostlyS = 0;$scope.r16AlwaysS = 0;$scope.r16NAS = 0;$scope.r16AvgS = 0;
		$scope.r17NeverS = 0;$scope.r17SometimesS = 0;$scope.r17OftenS = 0;$scope.r17MostlyS = 0;$scope.r17AlwaysS = 0;$scope.r17NAS = 0;$scope.r17AvgS = 0;
		$scope.r18NeverS = 0;$scope.r18SometimesS = 0;$scope.r18OftenS = 0;$scope.r18MostlyS = 0;$scope.r18AlwaysS = 0;$scope.r18NAS = 0;$scope.r18AvgS = 0;
		$scope.r19NeverS = 0;$scope.r19SometimesS = 0;$scope.r19OftenS = 0;$scope.r19MostlyS = 0;$scope.r19AlwaysS = 0;$scope.r19NAS = 0;$scope.r19AvgS = 0;
		$scope.r20NeverS = 0;$scope.r20SometimesS = 0;$scope.r20OftenS = 0;$scope.r20MostlyS = 0;$scope.r20AlwaysS = 0;$scope.r20NAS = 0;$scope.r20AvgS = 0;
		$scope.r21NeverS = 0;$scope.r21SometimesS = 0;$scope.r21OftenS = 0;$scope.r21MostlyS = 0;$scope.r21AlwaysS = 0;$scope.r21NAS = 0;$scope.r21AvgS = 0;
		$scope.r22NeverS = 0;$scope.r22SometimesS = 0;$scope.r22OftenS = 0;$scope.r22MostlyS = 0;$scope.r22AlwaysS = 0;$scope.r22NAS = 0;$scope.r22AvgS = 0;
		$scope.r23NeverS = 0;$scope.r23SometimesS = 0;$scope.r23OftenS = 0;$scope.r23MostlyS = 0;$scope.r23AlwaysS = 0;$scope.r23NAS = 0;$scope.r23AvgS = 0;
		$scope.r24NeverS = 0;$scope.r24SometimesS = 0;$scope.r24OftenS = 0;$scope.r24MostlyS = 0;$scope.r24AlwaysS = 0;$scope.r24NAS = 0;$scope.r24AvgS = 0;
		$scope.r25NeverS = 0;$scope.r25SometimesS = 0;$scope.r25OftenS = 0;$scope.r25MostlyS = 0;$scope.r25AlwaysS = 0;$scope.r25NAS = 0;$scope.r25AvgS = 0;
	}

	$scope.London = 0;
	$scope.Edinburgh = 0;
	$scope.Bangalore = 0;
	$scope.Chennai = 0;
	$scope.Gurugram = 0;
	$scope.Accounting = 0;
	$scope.EPM = 0;
	$scope.Credit = 0;
	$scope.ICB = 0;
	$scope.Performance = 0;
	$scope.Technology = 0;
	$scope.Treasury = 0;
	$scope.TreasurySol1 = 0;
	$scope.HR = 0;
	$scope.Financial = 0;
	$scope.Reporting = 0;
	$scope.Resolutions = 0;
	
	
	$scope.cleanData();
	
	$scope.GetTotData = function() {

		$scope.platform = document.getElementById('platform').value;
		$scope.loc = document.getElementById('location').value;
		$scope.timeperiod = document.getElementById('timeperiod').value;
		var status='active';
		 $http.get(urlBase + '/checklists/search/findByStatus?status='+ status).
         success(function (data) {
             if (data._embedded != undefined) {
                 $scope.checklists = data._embedded.checklists;
             } else {
                 $scope.checklists = [];
             }
                  
             if($scope.loc == 'totalData') {
					$scope.allLoc($scope.checklists);
				}
				else{ 
					$scope.SpecificLocPlatform($scope.checklists ,$scope.loc);
				}
             
             for(var i = 0;i<$scope.checklists.length; i++)
				{
					//console.log(i);
					switch($scope.checklists[i].location) {
						case "London":
							$scope.London++;
					//		console.log("london");
							break;
						case "Edinburgh":
							$scope.Edinburgh++;
					//		console.log("Edinburgh");
							break;
						case "Bangalore":
							$scope.Bangalore++;
					//		console.log("Bangalore");
							break;
						case "Chennai":
							$scope.Chennai++;
					//		console.log("Chennai");
							break;
						case "Gurugram":
							$scope.Gurugram++;
					//		console.log("Gurugram");
							break;
						default:
							alert("Something wrong contact admin");
					}
					
					
					switch($scope.checklists[i].platform) {
					case "accountingSol":
						$scope.Accounting++;
				//		console.log("london");
						break;
					case "CreditRisk":
						$scope.Credit++;
				//		console.log("Edinburgh");
						break;
					case "EPMandMarkets":
						$scope.EPM++;
				//		console.log("Bangalore");
						break;
					case "NonFinancial":
						$scope.Financial++;
				//		console.log("Chennai");
						break;
					case "ReportingSolutions":
						$scope.Reporting++;
				//		console.log("Gurugram");
						break;
					case "TreasurySolutions":
						$scope.TreasurySol1++;
				//		console.log("Gurugram");
						break;
					case "HRSolutions":
						$scope.HR++;
				//		console.log("Gurugram");
						break;
					case "ICBTransformation":
						$scope.ICB++;
				//		console.log("Gurugram");
						break;
					case "ResolutionsPlanning":
						$scope.Resolutions++;
				//		console.log("Gurugram");
						break;
					case "TechnologyTransformation":
						$scope.Technology++;
				//		console.log("Gurugram");
						break;
					case "TreasuryTransformation":
						$scope.Treasury++;
				//		console.log("Gurugram");
						break;
					case "PerformanceBusiness":
						$scope.Performance++;
				//		console.log("Gurugram");
						break;
					default:
						alert("Something wrong contact admin");
				}
					
					
				}
             
             
             
         });
		
	};
	
	$scope.GetaccountingSol = function() {
		$scope.platform = document.getElementById('platform').value;
		$scope.loc = document.getElementById('location').value;

		$http.get(urlBase + '/checklists/search/findByPlatform?platform=' + $scope.platform).
        success(function (data) {
            if (data._embedded != undefined) {
                $scope.accountingSol = data._embedded.checklists;
            } else {
                $scope.accountingSol = [];
            }
           // $scope.Accounting = $scope.accountingSol.length;
            if($scope.loc == 'totalData') {
				$scope.allLoc($scope.accountingSol);
			}
			else{ 
				$scope.SpecificLocPlatform($scope.accountingSol ,$scope.loc);
			}
          
        });
		
	};

	$scope.GetCreditRisk =function() {
		$scope.platform = document.getElementById('platform').value;
		$scope.loc = document.getElementById('location').value;
		
		
		$http.get(urlBase + '/checklists/search/findByPlatform?platform=' + $scope.platform).
        success(function (data) {
            if (data._embedded != undefined) {
                $scope.CreditRisk = data._embedded.checklists;
            } else {
                $scope.CreditRisk = [];
            }
            //$scope.Credit = $scope.CreditRisk.length;
            if($scope.loc == 'totalData') {
				$scope.allLoc($scope.CreditRisk);
			}
			else{ 
				$scope.SpecificLocPlatform($scope.CreditRisk ,$scope.loc);
			}
          
        });
	};
	$scope.GetEPMandMarkets = function() {
		$scope.platform = document.getElementById('platform').value;
		$scope.loc = document.getElementById('location').value;
		
		$http.get(urlBase + '/checklists/search/findByPlatform?platform=' + $scope.platform).
        success(function (data) {
            if (data._embedded != undefined) {
                $scope.EPMandMarkets = data._embedded.checklists;
            } else {
                $scope.EPMandMarkets = [];
            }
            //$scope.EPM = $scope.EPMandMarkets.length;
            if($scope.loc == 'totalData') {
				$scope.allLoc($scope.EPMandMarkets);
			}
			else{ 
				$scope.SpecificLocPlatform($scope.EPMandMarkets ,$scope.loc);
			}
          
        });
	};
	$scope.GetNonFinancial = function() {
		$scope.platform = document.getElementById('platform').value;
		$scope.loc = document.getElementById('location').value;

		$http.get(urlBase + '/checklists/search/findByPlatform?platform=' + $scope.platform).
        success(function (data) {
            if (data._embedded != undefined) {
                $scope.NonFinacial = data._embedded.checklists;
            } else {
                $scope.NonFinacial = [];
            }
            //$scope.Financial = $scope.NonFinancial.length;
            if($scope.loc == 'totalData') {
				$scope.allLoc($scope.NonFinacial);
			}
			else{ 
				$scope.SpecificLocPlatform($scope.NonFinacial ,$scope.loc);
			}
          
        });
	};
	$scope.GetReportingSolutions = function() {
		$scope.platform = document.getElementById('platform').value;
		$scope.loc = document.getElementById('location').value;
		
		$http.get(urlBase + '/checklists/search/findByPlatform?platform=' + $scope.platform).
        success(function (data) {
            if (data._embedded != undefined) {
                $scope.ReportingSolutions = data._embedded.checklists;
            } else {
                $scope.ReportingSolutions = [];
            }
			//$scope.Reporting = $scope.ReportingSolutions.length;
            if($scope.loc == 'totalData') {
				$scope.allLoc($scope.ReportingSolutions);
			}
			else{ 
				$scope.SpecificLocPlatform($scope.ReportingSolutions ,$scope.loc);
			}
          
        });
	};
	$scope.GetTreasurySolutions = function() {
		$scope.platform = document.getElementById('platform').value;
		$scope.loc = document.getElementById('location').value;
		
		$http.get(urlBase + '/checklists/search/findByPlatform?platform=' + $scope.platform).
        success(function (data) {
            if (data._embedded != undefined) {
                $scope.TreasurySolutions = data._embedded.checklists;
            } else {
                $scope.TreasurySolutions = [];
            }
			//$scope.TreasurySol1 = $scope.TreasurySolutions.length;
            if($scope.loc == 'totalData') {
				$scope.allLoc($scope.TreasurySolutions);
			}
			else{ 
				$scope.SpecificLocPlatform($scope.TreasurySolutions ,$scope.loc);
			}
          
        });
	};
	$scope.GetHRSolutions = function() {
		$scope.platform = document.getElementById('platform').value;
		$scope.loc = document.getElementById('location').value;
		
		$http.get(urlBase + '/checklists/search/findByPlatform?platform=' + $scope.platform).
        success(function (data) {
            if (data._embedded != undefined) {
                $scope.HRSolutions = data._embedded.checklists;
            } else {
                $scope.HRSolutions = [];
            }
			//$scope.HR = $scope.HRSolutions.length;
            if($scope.loc == 'totalData') {
				$scope.allLoc($scope.HRSolutions);
			}
			else{ 
				$scope.SpecificLocPlatform($scope.HRSolutions ,$scope.loc);
			}
          
        });
	};
	$scope.GetICBTransformation = function() {
		$scope.platform = document.getElementById('platform').value;
		$scope.loc = document.getElementById('location').value;
		
		$http.get(urlBase + '/checklists/search/findByPlatform?platform=' + $scope.platform).
        success(function (data) {
            if (data._embedded != undefined) {
                $scope.ICBTransformation = data._embedded.checklists;
            } else {
                $scope.ICBTransformation = [];
            }
			//$scope.ICB = $scope.ICBTransformation.length;
            if($scope.loc == 'totalData') {
				$scope.allLoc($scope.ICBTransformation);
			}
			else{ 
				$scope.SpecificLocPlatform($scope.ICBTransformation ,$scope.loc);
			}
          
        });
	};
	$scope.GetResolutionsPlanning = function() {
		$scope.platform = document.getElementById('platform').value;
		$scope.loc = document.getElementById('location').value;
		
		$http.get(urlBase + '/checklists/search/findByPlatform?platform=' + $scope.platform).
        success(function (data) {
            if (data._embedded != undefined) {
                $scope.ResolutionsPlanning = data._embedded.checklists;
            } else {
                $scope.ResolutionsPlanning = [];
            }
			//$scope.Resolutions = $scope.ResolutionsPlanning.length;
            if($scope.loc == 'totalData') {
				$scope.allLoc($scope.ResolutionsPlanning);
			}
			else{ 
				$scope.SpecificLocPlatform($scope.ResolutionsPlanning ,$scope.loc);
			}
          
        });
	};
	$scope.GetTechnologyTransformation = function() {
		$scope.platform = document.getElementById('platform').value;
		$scope.loc = document.getElementById('location').value;
		
		$http.get(urlBase + '/checklists/search/findByPlatform?platform=' + $scope.platform).
        success(function (data) {
            if (data._embedded != undefined) {
                $scope.TechnologyTransformation = data._embedded.checklists;
            } else {
                $scope.TechnologyTransformation = [];
            }
			//$scope.Technology = $scope.TechnologyTransformation.length;
            if($scope.loc == 'totalData') {
				$scope.allLoc($scope.TechnologyTransformation);
			}
			else{ 
				$scope.SpecificLocPlatform($scope.TechnologyTransformation ,$scope.loc);
			}
          
        });
	};
	$scope.GetTreasuryTransformation = function() {
		$scope.platform = document.getElementById('platform').value;
		$scope.loc = document.getElementById('location').value;
		
		$http.get(urlBase + '/checklists/search/findByPlatform?platform=' + $scope.platform).
        success(function (data) {
            if (data._embedded != undefined) {
                $scope.TreasuryTransformation = data._embedded.checklists;
            } else {
                $scope.TreasuryTransformation = [];
            }
			//$scope.Treasury = $scope.TreasuryTransformation.length;
            if($scope.loc == 'totalData') {
				$scope.allLoc($scope.TreasuryTransformation);
			}
			else{ 
				$scope.SpecificLocPlatform($scope.TreasuryTransformation ,$scope.loc);
			}
          
        });
		
		
	};
	$scope.GetPerformanceBusiness = function() {
		$scope.platform = document.getElementById('platform').value;
		$scope.loc = document.getElementById('location').value;
		
		$http.get(urlBase + '/checklists/search/findByPlatform?platform=' + $scope.platform).
        success(function (data) {
            if (data._embedded != undefined) {
                $scope.PerformanceBusiness = data._embedded.checklists;
            } else {
                $scope.PerformanceBusiness = [];
            }
			//$scope.Performance = $scope.PerformanceBusiness.length;
            if($scope.loc == 'totalData') {
				$scope.allLoc($scope.PerformanceBusiness);
			}
			else{ 
				$scope.SpecificLocPlatform($scope.PerformanceBusiness ,$scope.loc);
			}
          
        });
	};
	
/*	$scope.GetData = function(dataName, fileName) {
		console.log(" in GetData dataName: "+dataName+";fileName:"+fileName);
		$http({
		method: 'GET',
		url: fileName
		}).then(function (response){
			console.log(response.data);
			eval('$scope.'+dataName) = response.data;
			//eval('($scope.'+dataName+') = '+ response.data );
			console.log('after assign');
			console.log(eval('$scope.'+dataName));
			$scope.allLoc('$scope.' + $scope.platform);
			
		},function (error){console.log("error");});
	};
*/	
		//Initialize data
//		$scope.GetaccountingSol();
//		$scope.GetCreditRisk();
//		$scope.GetEPMandMarkets();
//		$scope.GetNonFinancial();
//		$scope.GetReportingSolutions();
//		$scope.GetTreasurySolutions();
//		$scope.GetHRSolutions();
//		$scope.GetICBTransformation();
//		$scope.GetResolutionsPlanning();
//		$scope.GetTechnologyTransformation();
//		$scope.GetTreasuryTransformation();
//		$scope.GetPerformanceBusiness();
		$scope.GetTotData();
		
	$scope.DataInit = function(){
		$scope.GetTotData();
		$scope.GetaccountingSol();
		$scope.GetCreditRisk();
		$scope.GetEPMandMarkets();
		$scope.GetNonFinancial();
		$scope.GetReportingSolutions();
		$scope.GetTreasurySolutions();
		$scope.GetHRSolutions();
		$scope.GetICBTransformation();
		$scope.GetResolutionsPlanning();
		$scope.GetTechnologyTransformation();
		$scope.GetTreasuryTransformation();
		$scope.GetPerformanceBusiness();
	}

	$scope.app = ['r1', 'r2', 'r3', 'r4', 'r5', 'r6', 'r7', 'r8', 'r9', 'r10', 'r12', 'r13', 'r14', 'r15', 'r16', 'r17', 'r18', 'r19', 'r20', 'r21', 'r22', 'r23', 'r24','r25'];
	$scope.app1 = ['question1','question2','question3','question4','question5','question6','question7','question8','question9','question10','question11','question12','question13','question14','question15','question16','question17','question18','question19','question20','question21','question22','question23','question24']
	 $scope.error =0;
	 
	 $scope.decide = function() {
		$scope.platform = document.getElementById('platform').value;
		$scope.loc = document.getElementById('location').value;
		$scope.timeperiod = document.getElementById('timeperiod').value;
		console.log($scope.platform);
		console.log($scope.loc);
		
		if ($scope.platform == 'totalData' && $scope.loc == 'totalData' && $scope.timeperiod == 'totalData')
		{
			 $scope.cleanData();
			 $scope.GetTotData();
		}
		else 
		{
			console.log("in decide else");
			$scope.cleanData();
			//$scope.GetData($scope.platform,String($scope.platform)+'.txt');
			switch ($scope.platform){
				case 'accountingSol':
						 $scope.GetaccountingSol();
						// $scope.allLoc($scope.accountingSol);
						break;
				case 'CreditRisk':
						 $scope.GetCreditRisk();
						// $scope.allLoc($scope.CreditRisk);
						break;
				case 'EPMandMarkets':
						 $scope.GetEPMandMarkets();
						// $scope.allLoc($scope.EPMandMarkets);
						break;
				case 'NonFinancial':
						 $scope.GetNonFinancial();
						// $scope.allLoc($scope.NonFinancial);
						break;
				case 'ReportingSolutions':
						 $scope.GetReportingSolutions();
						// $scope.allLoc($scope.ReportingSolutions);
						break;
				case 'TreasurySolutions':
						 $scope.GetTreasurySolutions();
						// $scope.allLoc($scope.TreasurySolutions);
						break;
				case 'HRSolutions':
						 $scope.GetHRSolutions();
						// $scope.allLoc($scope.HRSolutions);
						break;
				case 'ICBTransformation':
						 $scope.GetICBTransformation();
						// $scope.allLoc($scope.ICBTransformation);
						break;
				case 'ResolutionsPlanning':
						 $scope.GetResolutionsPlanning();
						// $scope.allLoc($scope.ResolutionsPlanning);
						break;
				case 'TechnologyTransformation':
						 $scope.GetTechnologyTransformation();
						// $scope.allLoc($scope.TechnologyTransformation);
						break;
				case 'TreasuryTransformation':
						 $scope.GetTreasuryTransformation();
						// $scope.allLoc($scope.TreasuryTransformation);
						break;
				case 'PerformanceBusiness':
						 $scope.GetPerformanceBusiness();
						// $scope.allLoc($scope.PerformanceBusiness);
						break;
				case 'totalData':
						 $scope.GetTotData();
						 break;
				default:
					alert("Failed to update contact admin");
			}
		}
	 };
	 
	
	 String.prototype.toDate = function(format)
	 {
	   var normalized      = this.replace(/[^a-zA-Z0-9]/g, '-');
	   var normalizedFormat= format.toLowerCase().replace(/[^a-zA-Z0-9]/g, '-');
	   var formatItems     = normalizedFormat.split('-');
	   var dateItems       = normalized.split('-');

	   var monthIndex  = formatItems.indexOf("mm");
	   var dayIndex    = formatItems.indexOf("dd");
	   var yearIndex   = formatItems.indexOf("yyyy");
	   var hourIndex     = formatItems.indexOf("hh");
	   var minutesIndex  = formatItems.indexOf("ii");
	   var secondsIndex  = formatItems.indexOf("ss");

	   var today = new Date();

	   var year  = yearIndex>-1  ? dateItems[yearIndex]    : today.getFullYear();
	   var month = monthIndex>-1 ? dateItems[monthIndex]-1 : today.getMonth()-1;
	   var day   = dayIndex>-1   ? dateItems[dayIndex]     : today.getDate();

	   var hour    = hourIndex>-1      ? dateItems[hourIndex]    : today.getHours();
	   var minute  = minutesIndex>-1   ? dateItems[minutesIndex] : today.getMinutes();
	   var second  = secondsIndex>-1   ? dateItems[secondsIndex] : today.getSeconds();

	   return new Date(year,month,day,hour,minute,second);
	 };
	 
	 
	$scope.allLoc = function(dataFinal) {
		$scope.cleanData();
		console.log("In final function ");
		console.log(dataFinal);
		var tfilter;
		if($scope.timeperiod == "totalData")
			{
				tfilter = 0;
			}
		else if($scope.timeperiod == "OneM")
			{
				tfilter = 2592000000;
			}
		else if($scope.timeperiod == "SixM")
			{
				tfilter = 15552000000;
			}
		else if($scope.timeperiod == "OneY")
		{
			tfilter = 31104000000;
		}
		else if($scope.timeperiod == "TwoY")
		{
			tfilter = 62208000000;
		}
		else if($scope.timeperiod == "ThreeY")
		{
			tfilter = 93312000000;
		}
		else if($scope.timeperiod == "FiveY")
		{
			tfilter = 155520000000;
		}
		
		
		for(var j =0;j<24;j++)
		{
			var x = $scope.app[j];
			var x1 = $scope.app1[j];
			for(var i = 0;i<dataFinal.length; i++)
			{
				var obj = dataFinal[i];
				var datatime = obj.survey_time.toDate("yyyy-mm-dd hh:ii:ss").getTime();
				var d = new Date();
			    var currenttime = d.getTime(); 
				//console.log(obj.survey_time.toDate("yyyy-mm-dd hh:ii:ss").getTime());
			if((tfilter!=0 &&(currenttime - datatime) <= tfilter) ||  tfilter == 0)
				{
				
				
				if(obj.self_flag == 'M')
					{
					switch(eval('obj.' + x1)) {
					case 1:
						eval('($scope.'+x+'NeverM)'+'='+ '($scope.'+x+'NeverM)' + '+1');
				//		eval('($scope.'+x+'Avg)'+'='+ '($scope.'+x+'Avg)' + '+1');
				//		console.log("london");
						break;
					case 2:
						eval('($scope.'+x+'SometimesM)'+'='+ '($scope.'+x+'SometimesM)' + '+1');
				//		eval('($scope.'+x+'Avg)'+'='+ '($scope.'+x+'Avg)' + '+1');
				//		console.log("Edinburgh");
						break;
					case 3:
						eval('($scope.'+x+'OftenM)'+'='+ '($scope.'+x+'OftenM)' + '+1');
				//		eval('($scope.'+x+'Avg)'+'='+ '($scope.'+x+'Avg)' + '+1');
				//		console.log("Bangalore");
						break;
					case 4:
						eval('($scope.'+x+'MostlyM)'+'='+ '($scope.'+x+'MostlyM)' + '+1');
				//		eval('($scope.'+x+'Avg)'+'='+ '($scope.'+x+'Avg)' + '+1');
				//		console.log("Chennai");
						break;
					case 5:
						eval('($scope.'+x+'AlwaysM)'+'='+ '($scope.'+x+'AlwaysM)' + '+1');
				//		eval('($scope.'+x+'Avg)'+'='+ '($scope.'+x+'Avg)' + '+1');
				//		console.log("Gurugram");
						break;
					case 0:
						eval('($scope.'+x+'NAM)'+'='+ '($scope.'+x+'NAM)' + '+1');
				//		eval('($scope.'+x+'Avg)'+'='+ '($scope.'+x+'Avg)' + '+1');
				//		console.log("Gurugram");
						break;
					default:
						alert("Something wrong contact admin");
						 $scope.error =1;
						break;
						//eval('($scope.'+x+'Avg)'+'='+ '($scope.'+x+'Avg)' + '+1');
				        //console.log("Gurugram");
						//break;
		
				}
					}
				
				else if(obj.self_flag =='S' )
					{
					switch(eval('obj.' + x1)) {
					case 1:
						eval('($scope.'+x+'NeverS)'+'='+ '($scope.'+x+'NeverS)' + '+1');
				//		eval('($scope.'+x+'Avg)'+'='+ '($scope.'+x+'Avg)' + '+1');
				//		console.log("london");
						break;
					case 2:
						eval('($scope.'+x+'SometimesS)'+'='+ '($scope.'+x+'SometimesS)' + '+1');
				//		eval('($scope.'+x+'Avg)'+'='+ '($scope.'+x+'Avg)' + '+1');
				//		console.log("Edinburgh");
						break;
					case 3:
						eval('($scope.'+x+'OftenS)'+'='+ '($scope.'+x+'OftenS)' + '+1');
				//		eval('($scope.'+x+'Avg)'+'='+ '($scope.'+x+'Avg)' + '+1');
				//		console.log("Bangalore");
						break;
					case 4:
						eval('($scope.'+x+'MostlyS)'+'='+ '($scope.'+x+'MostlyS)' + '+1');
				//		eval('($scope.'+x+'Avg)'+'='+ '($scope.'+x+'Avg)' + '+1');
				//		console.log("Chennai");
						break;
					case 5:
						eval('($scope.'+x+'AlwaysS)'+'='+ '($scope.'+x+'AlwaysS)' + '+1');
				//		eval('($scope.'+x+'Avg)'+'='+ '($scope.'+x+'Avg)' + '+1');
				//		console.log("Gurugram");
						break;
					case 0:
						eval('($scope.'+x+'NAS)'+'='+ '($scope.'+x+'NAS)' + '+1');
				//		eval('($scope.'+x+'Avg)'+'='+ '($scope.'+x+'Avg)' + '+1');
				//		console.log("Gurugram");
						break;
					default:
						alert("Something wrong contact admin");
						 $scope.error =1;
						break;
						//eval('($scope.'+x+'Avg)'+'='+ '($scope.'+x+'Avg)' + '+1');
				        //console.log("Gurugram");
						//break;
		
				}
					}
				//console.log(obj.self_flag);
				
				
				if($scope.error === 1)
				{
					break;
				}
				}
			}	
			eval('($scope.'+x+'rowTotalM)'+'='+ '0');
			eval('($scope.'+x+'rowTotalS)'+'='+ '0');
			/*
			eval('($scope.'+x+'Avg)'+'=' + '(1 * ($scope.'+x+'Never)) + ' + '(2 * ($scope.'+x+'Sometimes) )+ '+ '(3 * ($scope.'+x+'Often)) + '+'(4 * ($scope.'+x+'Mostly) )+ '+'(5 * ($scope.'+x+'Always)) + ' + '(0 * ($scope.'+x+'NA))' ); 
			//row total 
			eval('($scope.'+x+'rowTotal)'+'=' + '($scope.'+x+'Never) + ' + '($scope.'+x+'Sometimes)+ '+ '($scope.'+x+'Often) + '+'($scope.'+x+'Mostly) + '+'($scope.'+x+'Always) + ' + '($scope.'+x+'NA)' ); 
			//avr of row
			*/
			
			eval('($scope.'+x+'AvgM)'+'=' + '(1 * ($scope.'+x+'NeverM)) + ' + '(2 * ($scope.'+x+'SometimesM) )+ '+ '(3 * ($scope.'+x+'OftenM)) + '+'(4 * ($scope.'+x+'MostlyM) )+ '+'(5 * ($scope.'+x+'AlwaysM))'); 
			//row total of manager 
			
			eval('($scope.'+x+'AvgS)'+'=' + '(1 * ($scope.'+x+'NeverS)) + ' + '(2 * ($scope.'+x+'SometimesS) )+ '+ '(3 * ($scope.'+x+'OftenS)) + '+'(4 * ($scope.'+x+'MostlyS) )+ '+'(5 * ($scope.'+x+'AlwaysS))'); 
			//row total of self
			
			eval('($scope.'+x+'rowTotalM)'+'=' + '($scope.'+x+'NeverM) + ' + '($scope.'+x+'SometimesM)+ '+ '($scope.'+x+'OftenM) + '+'($scope.'+x+'MostlyM) + '+'($scope.'+x+'AlwaysM)'); 
			//avr of row of manager
			
			eval('($scope.'+x+'rowTotalS)'+'=' + '($scope.'+x+'NeverS) + ' + '($scope.'+x+'SometimesS)+ '+ '($scope.'+x+'OftenS) + '+'($scope.'+x+'MostlyS) + '+'($scope.'+x+'AlwaysS)'); 
			//avr of row of self
			
			
			if(eval('($scope.'+x+'rowTotalM)') !=0)
				{
				eval('($scope.'+x+'AvgM)'+'='+ '($scope.'+x+'AvgM)' + '/' + '($scope.'+x+'rowTotalM)');
				}
			
			if(eval('($scope.'+x+'rowTotalS)') !=0)
			{
			eval('($scope.'+x+'AvgS)'+'='+ '($scope.'+x+'AvgS)' + '/' + '($scope.'+x+'rowTotalS)');
			}
			
			
			eval('($scope.'+x+'AvgM)'+'='+ 'Math.round(($scope.'+x+'AvgM) * 100)' + '/100');
			eval('($scope.'+x+'AvgS)'+'='+ 'Math.round(($scope.'+x+'AvgS) * 100)' + '/100');
			
			
			if($scope.error === 1)
				{
					break;
				}
		}
	};	
/*	console.log($scope.r1Never);
	console.log($scope.r1Sometimes);
	console.log($scope.r1Often);console.log($scope.r1Mostly);
	console.log($scope.r1Always);
	console.log($scope.r1NA);
*/	
	$scope.SpecificLocPlatform = function(originalData, loc) {
		
		var newArray = [];
		
		for(var i = 0;i<originalData.length; i++)
		{
			//console.log(originalData[i].location);
			if (originalData[i].location == loc)
			{
				
				newArray.push(originalData[i]);
			}
		}
		if(newArray.length ===0){
			$scope.cleanData();
			console.log("empty array");
		}
		else {
			console.log(newArray);
			$scope.allLoc(newArray);
		}
	}
	$scope.ragClassFunc = function (score_type) {
  if (score_type >= 0 && score_type < 2) {
    return 'red';
  } else if (score_type >= 2 && score_type <3.5) {
    return 'amber';
  } else if (score_type >= 3.5 && score_type <=5) {
    return 'green';
  } else {
	return 'default';
  }
};
});