package org.gourav.demo;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="checklist")
public class Checklist {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="id")
	private int id;
	
	@Column(name="status")
	private String status;


	@Column(name="survey_time")
	private String survey_time;
	
	@Column(name="username")
	private String username;
	
	@Column(name="platform")
	private String platform;
	
	@Column(name="location")
	private String location;
	
	@Column(name="self_flag")
	private String self_flag;
	
	@Column(name="manager_username")
	private String manager_username;
	
	@Column(name="question1")
	private int question1;
	
	@Column(name="question2")
	private int question2;
	
	@Column(name="question3")
	private int question3;
	
	@Column(name="question4")
	private int question4;
	
	@Column(name="question5")
	private int question5;
	
	@Column(name="question6")
	private int question6;
	
	@Column(name="question7")
	private int question7;
	
	@Column(name="question8")
	private int question8;
	
	@Column(name="question9")
	private int question9;
	
	@Column(name="question10")
	private int question10;
	
	@Column(name="question11")
	private int question11;
	
	@Column(name="question12")
	private int question12;
	
	@Column(name="question13")
	private int question13;
	
	@Column(name="question14")
	private int question14;
	
	@Column(name="question15")
	private int question15;
	
	@Column(name="question16")
	private int question16;
	
	@Column(name="question17")
	private int question17;
	
	@Column(name="question18")
	private int question18;
	
	@Column(name="question19")
	private int question19;
	
	@Column(name="question20")
	private int question20;
	
	@Column(name="question21")
	private int question21;
	
	@Column(name="question22")
	private int question22;
	
	@Column(name="question23")
	private int question23;
	
	@Column(name="question24")
	private int question24;
	

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPlatform() {
		return platform;
	}
	public void setPlatform(String platform) {
		this.platform = platform;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getSelf_flag() {
		return self_flag;
	}
	public void setSelf_flag(String self_flag) {
		this.self_flag = self_flag;
	}
	public String getManager_username() {
		return manager_username;
	}
	public void setManager_username(String manager_username) {
		this.manager_username = manager_username;
	}
	public int getQuestion1() {
		return question1;
	}
	public void setQuestion1(int question1) {
		this.question1 = question1;
	}
	public int getQuestion2() {
		return question2;
	}
	public void setQuestion2(int question2) {
		this.question2 = question2;
	}
	public int getQuestion3() {
		return question3;
	}
	public void setQuestion3(int question3) {
		this.question3 = question3;
	}
	public int getQuestion4() {
		return question4;
	}
	public void setQuestion4(int question4) {
		this.question4 = question4;
	}
	public int getQuestion5() {
		return question5;
	}
	public void setQuestion5(int question5) {
		this.question5 = question5;
	}
	public int getQuestion6() {
		return question6;
	}
	public void setQuestion6(int question6) {
		this.question6 = question6;
	}
	public int getQuestion7() {
		return question7;
	}
	public void setQuestion7(int question7) {
		this.question7 = question7;
	}
	public int getQuestion8() {
		return question8;
	}
	public void setQuestion8(int question8) {
		this.question8 = question8;
	}
	public int getQuestion9() {
		return question9;
	}
	public void setQuestion9(int question9) {
		this.question9 = question9;
	}
	public int getQuestion10() {
		return question10;
	}
	public void setQuestion10(int question10) {
		this.question10 = question10;
	}
	public int getQuestion11() {
		return question11;
	}
	public void setQuestion11(int question11) {
		this.question11 = question11;
	}
	public int getQuestion12() {
		return question12;
	}
	public void setQuestion12(int question12) {
		this.question12 = question12;
	}
	public int getQuestion13() {
		return question13;
	}
	public void setQuestion13(int question13) {
		this.question13 = question13;
	}
	public int getQuestion14() {
		return question14;
	}
	public void setQuestion14(int question14) {
		this.question14 = question14;
	}
	public int getQuestion15() {
		return question15;
	}
	public void setQuestion15(int question15) {
		this.question15 = question15;
	}
	public int getQuestion16() {
		return question16;
	}
	public void setQuestion16(int question16) {
		this.question16 = question16;
	}
	public int getQuestion17() {
		return question17;
	}
	public void setQuestion17(int question17) {
		this.question17 = question17;
	}
	public int getQuestion18() {
		return question18;
	}
	public void setQuestion18(int question18) {
		this.question18 = question18;
	}
	public int getQuestion19() {
		return question19;
	}
	public void setQuestion19(int question19) {
		this.question19 = question19;
	}
	public int getQuestion20() {
		return question20;
	}
	public void setQuestion20(int question20) {
		this.question20 = question20;
	}
	public int getQuestion21() {
		return question21;
	}
	public void setQuestion21(int question21) {
		this.question21 = question21;
	}
	public int getQuestion22() {
		return question22;
	}
	public void setQuestion22(int question22) {
		this.question22 = question22;
	}
	public int getQuestion23() {
		return question23;
	}
	public void setQuestion23(int question23) {
		this.question23 = question23;
	}
	public int getQuestion24() {
		return question24;
	}
	public void setQuestion24(int question24) {
		this.question24 = question24;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSurvey_time() {
		return survey_time;
	}
	public void setSurvey_time(String survey_time) {
		this.survey_time = survey_time;
	}
	 @Override
	 public String toString() {
	  return "Checklist [id=" + id + ", username=" + username
	    + ", platform=" + platform + ", location="
	    + location + ", self_flag=" + self_flag + ", manager_username=" + manager_username + ", question1=" + question1 + ", question2=" + question2 + ", question3=" + question3 + ", question4=" + question4 + ", question5=" + question5 + ", question6=" + question6 + ", question7=" + question7 + ", question8=" + question8 + ", question9=" + question9 + ", question10=" + question10 + ", question11=" + question11 + ", question12=" + question12 + ", question13=" + question13 + ", question14=" + question14 + ", question15=" + question15 + ", question16=" + question16 + ", question17=" + question17 + ", question18=" + question18 + ", question19=" + question19 + ", question20=" + question20+ ", question21=" + question21 + ", question22=" + question22 + ", question23=" + question23 + ", question24=" + question24 + "]";
	 }
}
