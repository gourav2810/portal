package org.gourav.demo;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class HomeController {

	@Autowired
	ChecklistRepository repository;
	
	@RequestMapping("/")
	public String hello()
	{
		return "LeadersChecklist";
	}
	
	@RequestMapping("/heatmap")
	public String heatmap()
	{
		return "heatmap";
	}
	
	@RequestMapping("/locmetrics")
	public String loc()
	{
		return "LCPlatformLocMetrics";
	}
	
	
	@RequestMapping("/leadercomp")
	public String leadercomp()
	{
		return "LeaderComp";
	}
	
}
