<?php
include("includes/db.php");
if(isset($_POST['tlogin']))
{
   $tcode=$_POST['tcode'];
    $tpass=$_POST['tpass'];
    $get_query="Select * from teacher where tcode='$tcode' and tpass='$tpass'";
    $run_query=mysqli_query($con,$get_query);
            $count=mysqli_num_rows($run_query);
            if($count>0)
{
$row_query=mysqli_fetch_assoc($run_query);
$tname=$row_query['tname'];
}
}

?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Welcome <?php $tname?></title>
        <link rel="stylesheet" href="css/bootstrap.min.css" media="screen" >
        <link rel="stylesheet" href="css/font-awesome.min.css" media="screen" >
        <link rel="stylesheet" href="css/animate-css/animate.min.css" media="screen" >
        <link rel="stylesheet" href="css/prism/prism.css" media="screen" > <!-- USED FOR DEMO HELP - YOU CAN REMOVE IT -->
        <link rel="stylesheet" href="css/main.css" media="screen" >
        <script src="js/modernizr/modernizr.min.js"></script>
    </head>
    <body class="">
        <div class="main-wrapper">

            <div class="">
                <div class="row">
 <h1 align="center">Academic Portal</h1>
                  
                    <div class="col-lg-6">
                        <section class="section">
                            <div class="row mt-40">
                                <div class="col-md-10 col-md-offset-8 pt-50">

                                    <div class="row mt-30 ">
                                        <div class="col-md-11">
                                            <div class="panel">
                                                <div class="panel-heading">
                                                    <div class="panel-title text-center">
                                                        <h4>Teacher details</h4>
                                                    </div>
                                                </div>
                                                <div class="panel-body p-20">
                                                    <div class="section-title">
                                                        <p class="sub-title">Teacher Name: <?php  echo $tname ?></p>
                                                    </div>

                                                    
                                                      
                                                        <div class="form-group">
                                                        
                                                        <form method="post" action="upload.php">
                                                           <div class="col-sm-10">
                                                           <b>Course:</b>  
                                                                <select name="ctu">
                                                            <option>Select Course</option>
                                                            <?php
                                                            $get_cat="select * from course where tcode='$tcode'";
                                                            $run_cat=mysqli_query($con,$get_cat);
                                                            while($row_cat=mysqli_fetch_array($run_cat))
                                                            {
                                                            $cat_title=$row_cat['ccode'];
                                                            echo "<option>$cat_title</option>"; 
                                                            }
                                                            ?>
                                                            </select>
                                                            <br>
                                                            </div>
                                                           <div class="col-sm-10">
                                                           <b>Exam:</b>
                                                                <select name="marks">
                                                                <option>Select a category</option>
                                                                <option>cat1</option>
                                                                <option>cat2</option>
                                                                <option>final</option>
                                                                </select>
                                                            </div><br>
                                                            </div>
                                                            <div class="col-sm-10">
                                                            <b>Student:</b>
                                                                <select name="stu">
                                                            <option>Select student</option>
                                                            <?php
                                                            $get_cat="select * from student";
                                                            $run_cat=mysqli_query($con,$get_cat);
                                                            while($row_cat=mysqli_fetch_array($run_cat))
                                                            {
                                                            $cat_title=$row_cat['sname'];
                                                            echo "<option>$cat_title</option>"; 
                                                            }
                                                            ?>
                                                            </select>
                                                            <br>
                                                            </div>
                                                            <div class="col-sm-10">
                                                            <b>Marks:<input type="text" size="5" name="tmarks" /></b>
                                                            </div>
                                                        
                                                        
                                                    
                                                        <div class="form-group mt-20">
                                                            <div class="col-sm-offset-2 col-sm-10">
                                                           
                                                                <button type="submit" name="mupload" class="btn btn-success btn-labeled pull-right">Upload<span class="btn-label btn-label-right"><i class="fa fa-check"></i></span></button>
                                                            </div>
                                                        </div>
                                                    </form>

                                            

                                                 
                                                </div>
                                            </div>
                                            <!-- /.panel -->
                                            <p class="text-muted text-center"><small>Copyright © Gourav2017</small></p>
                                        </div>
                                        <!-- /.col-md-11 -->
                                    </div>
                                    <!-- /.row -->
                                </div>
                                <!-- /.col-md-12 -->
                            </div>
                            <!-- /.row -->
                        </section>

                    </div>
                    <!-- /.col-md-6 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /. -->

        </div>
        <!-- /.main-wrapper -->

        <!-- ========== COMMON JS FILES ========== -->
        <script src="js/jquery/jquery-2.2.4.min.js"></script>
        <script src="js/jquery-ui/jquery-ui.min.js"></script>
        <script src="js/bootstrap/bootstrap.min.js"></script>
        <script src="js/pace/pace.min.js"></script>
        <script src="js/lobipanel/lobipanel.min.js"></script>
        <script src="js/iscroll/iscroll.js"></script>

        <!-- ========== PAGE JS FILES ========== -->

        <!-- ========== THEME JS ========== -->
        <script src="js/main.js"></script>
        <script>
            $(function(){

            });
        </script>

        <!-- ========== ADD custom.js FILE BELOW WITH YOUR CHANGES ========== -->
    </body>
</html>