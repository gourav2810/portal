<?php
include("includes/db.php");
if(isset($_POST['slogin']))
{
    $sroll=$_POST['sroll'];
    $spass=$_POST['spass'];
    $get_query="Select * from student where sroll='$sroll' and spass='$spass'";
    $run_query=mysqli_query($con,$get_query);
            $count=mysqli_num_rows($run_query);
            if($count>0)
{
$row_query=mysqli_fetch_assoc($run_query);
$sname=$row_query['sname'];
$semail=$row_query['semail'];

}
}
?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Welcome <?php $sname?></title>
        <link rel="stylesheet" href="css/bootstrap.min.css" media="screen" >
        <link rel="stylesheet" href="css/font-awesome.min.css" media="screen" >
        <link rel="stylesheet" href="css/animate-css/animate.min.css" media="screen" >
        <link rel="stylesheet" href="css/prism/prism.css" media="screen" > <!-- USED FOR DEMO HELP - YOU CAN REMOVE IT -->
        <link rel="stylesheet" href="css/main.css" media="screen" >
        <script src="js/modernizr/modernizr.min.js"></script>
    </head>
    <body class="">
        <div class="main-wrapper">

            <div class="">
                <div class="row">
 <h1 align="center">Academic Portal</h1>
                  
                    <div class="col-lg-6">
                        <section class="section">
                            <div class="row mt-40">
                                <div class="col-md-10 col-md-offset-8 pt-50">

                                    <div class="row mt-30 ">
                                        <div class="col-md-11">
                                            <div class="panel">
                                                <div class="panel-heading">
                                                    <div class="panel-title text-center">
                                                        <h4>Student details</h4>
                                                    </div>
                                                </div>
                                                <div class="panel-body p-20">

                                                    <div class="section-title">
                                                        <p class="sub-title">Name: <?php  echo $sname ?></p>
                                                    </div>

                                                    
                                                        

<?php
                                                        $get_query="Select * from marks where stuname='$sname'";
                                                        $run_query=mysqli_query($con,$get_query);
                                                        while($row_query=mysqli_fetch_assoc($run_query))
                                                        {

                                                        	$sub=$row_query['suid'];
                                                        	$cat1=$row_query['cat1'];
                                                        	$cat2=$row_query['cat2'];
                                                        	$final=$row_query['final'];
                                                        	echo 'Course-'.$sub.'
                                                        
                                                            Cat1-
                                                            '.
                                                              $cat1.'
                                                            
                                                            
                                                            Cat2-
                                                            '.
                                                                $cat2.'
                                                            
                                                        
                                                            TermEnd-
                                                            '.
                                                               $final.'
                                                            
                                                       <br/>';
                                                       
                                                        }?>
                                                        
                                                     
                                             

                                            

                                                 
                                                </div>
                                            </div>
                                            <!-- /.panel -->
                                            <p class="text-muted text-center"><small>Copyright © Gourav2017</small></p>
                                        </div>
                                        <!-- /.col-md-11 -->
                                    </div>
                                    <!-- /.row -->
                                </div>
                                <!-- /.col-md-12 -->
                            </div>
                            <!-- /.row -->
                        </section>

                    </div>
                    <!-- /.col-md-6 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /. -->

        </div>
        <!-- /.main-wrapper -->

        <!-- ========== COMMON JS FILES ========== -->
        <script src="js/jquery/jquery-2.2.4.min.js"></script>
        <script src="js/jquery-ui/jquery-ui.min.js"></script>
        <script src="js/bootstrap/bootstrap.min.js"></script>
        <script src="js/pace/pace.min.js"></script>
        <script src="js/lobipanel/lobipanel.min.js"></script>
        <script src="js/iscroll/iscroll.js"></script>

        <!-- ========== PAGE JS FILES ========== -->

        <!-- ========== THEME JS ========== -->
        <script src="js/main.js"></script>
        <script>
            $(function(){

            });
        </script>

        <!-- ========== ADD custom.js FILE BELOW WITH YOUR CHANGES ========== -->
    </body>
</html>