<?php
global $con;
$con=mysqli_connect("localhost","root","","srms");
?>