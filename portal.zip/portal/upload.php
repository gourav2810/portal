<?php
include("includes/db.php");
if(isset($_POST['mupload']))
{
    $marks=$_POST['marks'];
    $tmarks=$_POST['tmarks'];
    $code=$_POST['ctu'];
    $scode=$_POST['stu'];
    $get_query="Select * from marks where stuname='$scode' and suid='$code'";
    $run_query=mysqli_query($con,$get_query);
            $count=mysqli_num_rows($run_query);
            if($count==0)
            {
              $get_query1="insert into marks(stuname,suid,cat1,cat2,final) values('$scode','$code','-','-','-')";
                $run_query1=mysqli_query($con,$get_query1);
            }
            $get_query2="update marks set $marks='$tmarks' where stuname='$scode' and suid='$code'";
           $run_query2=mysqli_query($con,$get_query2);
}
?>